<?php

namespace Inertia;

interface IgnoreFirstLoad
{
    //
}
