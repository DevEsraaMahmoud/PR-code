<?php

namespace Inertia\Middleware;

use Inertia\EncryptHistoryMiddleware;

class EncryptHistory extends EncryptHistoryMiddleware
{
    //
}
